/*
SELECT
        c.first_name, c.last_name, c.email, o.order_id,
        o.creation_date, o.total_due, o.status,
        s.first_name, s.last_name, s.email,
        ol.quantity,
        p.code, p.name, p.size, p.variety, p.price
        from orders o
        join customer c on o.customer_id = c.customer_id
        join salesperson s on
        o.salesperson_id=s.salesperson_id
        join order_item ol on ol.order_id=o.order_id
        join product p on ol.product_id = p.product_id
        where o.order_id = ?;

 */

package ca.jrvs.apps.jdbc;

import ca.jrvs.apps.jdbc.util.DataTransferObject;

import java.math.BigDecimal;
import java.util.Date;

public class OrderOriginal implements DataTransferObject {


    private String customerFirstName;
    private String customerLastName;
    private String customerEmail;
    private long customerOrderId;
    private Date orderCreationDate;
    private BigDecimal orderTotalDue;
    private String orderStatus;
    private String salespersonFirstName;
    private String salespersonLastName;
    private String salespersonEmail;
    private int orderItemQuantity;
    private String productCode;
    private String productName;
    private int productSize;
    private String productVariety;
    private BigDecimal productPrice;





    public String getCustomerFirstName() { return customerFirstName; }
    public void setCustomerFirstName(String customerFirstName) { this.customerFirstName = customerFirstName; }

    public String getCustomerLastName() { return customerLastName; }
    public void setCustomerLastName(String customerLastName) { this.customerLastName = customerLastName; }

    public String getCustomerEmail() { return customerEmail; }
    public void setCustomerEmail(String customerEmail) { this.customerEmail = customerEmail; }

    public long getCustomerOrderId() { return customerOrderId; }
    public void setCustomerOrderId(long customerOrderId) { this.customerOrderId = customerOrderId; }

    public Date getOrderCreationDate() { return orderCreationDate; }
    public void setOrderCreationDate (Date orderCreationDate) { this.orderCreationDate = orderCreationDate; }

    public BigDecimal getOrderTotalDue() { return orderTotalDue; }
    public void setOrderTotalDue (BigDecimal orderTotalDue) { this.orderTotalDue = orderTotalDue; }

    public String getOrderStatus() { return orderStatus; }
    public void setOrderStatus (String orderStatus) { this.orderStatus = orderStatus; }

    public String getSalespersonFirstName() { return salespersonFirstName; }
    public void setSalespersonFirstName (String salespersonFirstName) { this.salespersonFirstName = salespersonFirstName; }

    public String getSalespersonLastName() { return salespersonLastName; }
    public void setSalespersonLastName (String salespersonLastName) { this.salespersonLastName = salespersonLastName; }

    public String getSalespersonEmail() { return salespersonEmail; }
    public void setSalespersonEmail (String salespersonEmail) { this.salespersonEmail = salespersonEmail; }

    public int getOrderItemQuantity() { return orderItemQuantity; }
    public void setOrderItemQuantity (int orderItemQuantity) { this.orderItemQuantity = orderItemQuantity; }

    public String getProductCode() { return productCode; }
    public void setProductCode (String productCode) { this.productCode = productCode; }

    public String getProductName() { return productName; }
    public void setProductName (String productName) { this.productName = productName; }

    public int getProductSize() { return productSize; }
    public void setProductSize (int productSize) { this.productSize = productSize; }

    public String getProductVariety() { return productVariety; }
    public void setProductVariety (String productVariety) { this.productVariety = productVariety; }

    public BigDecimal getProductPrice() { return productPrice; }
    public void setProductPrice (BigDecimal productPrice) { this.productPrice = productPrice; }




    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Order{");
        sb.append("customerFirstName=").append(customerFirstName);
        sb.append(", cusomterLastName='").append(customerLastName).append('\'');
        sb.append(", customerEmail='").append(customerEmail).append('\'');
        sb.append(", customerOrderId='").append(customerOrderId).append('\'');
        sb.append(", orderCreationDate='").append(orderCreationDate).append('\'');
        sb.append(", orderTotalDue='").append(orderTotalDue).append('\'');
        sb.append(", orderStatus='").append(orderStatus).append('\'');
        sb.append(", salespersonFirstName='").append(salespersonFirstName).append('\'');
        sb.append(", salespersonLastName='").append(salespersonLastName).append('\'');
        sb.append(", salespersonEmail='").append(salespersonEmail).append('\'');
        sb.append(", orderItemQuantity='").append(orderItemQuantity).append('\'');
        sb.append(", productCode='").append(productCode).append('\'');
        sb.append(", productName='").append(productName).append('\'');
        sb.append(", productSize='").append(productSize).append('\'');
        sb.append(", productVariety='").append(productVariety).append('\'');
        sb.append(", productPrice='").append(productPrice).append('\'');
        sb.append('}');
        return sb.toString();
    }


    @Override
    public long getId() {
        return 0;
    }
}