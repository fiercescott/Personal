package ca.jrvs.apps.twitter;

import ca.jrvs.apps.twitter.dao.helper.ApacheHttpHelper;
import ca.jrvs.apps.twitter.example.dto.Coordinates;


public interface restdao<T, ID> {
/*
    T create(T entity)
    {
        String tweet = "test";
        Tweet tweetStr = new Tweet();
        tweet.setTesct(tweetStr);
        Coordinated coordinates = new Coordinates();
        coordinates.setCoordinates(Arrays.asList(100.0,200.0));
        tweet.setCoordinates(coordinates);


        //callcreate method
        HttpHelper httpHelper = new ApacheHttpHelper();
        TwitterRestDao dao = new TwitterRestDao(httpHelper);
        Tweet actualTweet = dao.create(tweet);

        //validate tweet object
        assertNotNull(actualTweet);
        asertNotNull(actualTweet.getIdStr());
        assertEquals(tweet.getText(), actualTweet.getText());
        //assert all vars


    }
    T findById(ID id);
    T deleteById(ID id);
*/
}
