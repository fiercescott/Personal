package ca.jrvs.apps.twitter.example.dto;


public class Coordinates{

    double coordinates[] = new double[2];
    String type;


    public double[] getCoordinates() {
        return coordinates;
    }

    public void setCoordinates(double[] coordinates) {
        this.coordinates = coordinates;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}