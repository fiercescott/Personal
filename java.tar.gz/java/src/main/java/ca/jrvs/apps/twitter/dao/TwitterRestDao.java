package ca.jrvs.apps.twitter.dao;

import ca.jrvs.apps.twitter.dao.helper.HttpHelper;
import ca.jrvs.apps.twitter.example.JsonParser;
import ca.jrvs.apps.twitter.example.dto.Tweet;
import org.apache.http.HttpResponse;
import org.apache.http.entity.StringEntity;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;





import ca.jrvs.apps.twitter.dao.helper.HttpHelper;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import org.apache.http.HttpResponse;
import org.apache.http.util.EntityUtils;






import static javax.swing.UIManager.get;

//public interface TwitterRestDao implements CrdRepository <Tweet, String> {
public class TwitterRestDao {

    private static String consumerKeyStr = "fH03Chc2YOcuP3OOuMcOfvrmc";
    private static String consumerSecretStr = "3mEAK7pMpiB7dcE4cWLLVmxwPeOAr2HHiCXcDVfEE6ut3zFBIf";
    private static String accessTokenStr = "1144303955297673218-9imbJs9lycc6UzRVusK0N0vshplOdu";
    private static String accessTokenSecretStr = "HhNViIx6pE0WGkCJXnX8El8LHufpAjE3tehKzdWVd5Qdu";



    private static String twitterPostUrl = "https://api.twitter.com/1.1/statuses/update.json";
    private static String twitterGetUrl = "https://api.twitter.com/1.1/statuses/show.json";
    private static String twitterDeleteUrl = "https://api.twitter.com/1.1/statuses/destroy/";

    static String queryStr = "?";

    static final int HTTP_OK = 200;

    private static HttpHelper httpHelper;

    public TwitterRestDao(HttpHelper httpHelper) {
        this.httpHelper = httpHelper;
    }

    public static Tweet postTweet(Tweet tweet){

        Tweet response = null;
        URI uri = null;

        try{
            uri = getPostUri(tweet);
        } catch (UnsupportedEncodingException | URISyntaxException e) {
            e.printStackTrace();
        }

        HttpResponse httpResponse = httpHelper.httpPost(uri);

        return validateTweetResponse(httpResponse, HTTP_OK);
    }

    public static Tweet getTweetById(String id) {
        URI uri;
        try{
            uri = getGetUri(id);
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException("Unable to construct URI", e);
        }

        HttpResponse httpResponse = httpHelper.httpPost(uri);

        return validateTweetResponse(httpResponse, HTTP_OK);
    }

    public static Tweet deleteTweetById(String id) {
        URI uri;
        try{
            uri = getDeleteUri(id);
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException("Unable to construct URI", e);
        }

        HttpResponse httpResponse = httpHelper.httpPost(uri);

        return validateTweetResponse(httpResponse, HTTP_OK);
    }



    public static URI getPostUri (Tweet tweet) throws URISyntaxException, UnsupportedEncodingException {
        String uriString = "";

        uriString = twitterPostUrl;
        uriString = uriString + queryStr;

        double longitude = tweet.getCoordinates().getCoordinates()[0];
        double latitude = tweet.getCoordinates().getCoordinates()[1];

        addParamToURI(uriString, "status", URLEncoder.encode(tweet.getText(), StandardCharsets.UTF_8.name()), true);
        addParamToURI(uriString, "long", Double.toString(longitude), false);
        addParamToURI(uriString, "lat", Double.toString(latitude), false);

        return new URI(uriString);
    }


    public static URI getDeleteUri (String id) throws URISyntaxException {
        String uriString = "";

        uriString = twitterDeleteUrl + id + ".json";

        return new URI(uriString);

    }

    public static URI getGetUri (String id) throws URISyntaxException {
        String uriString = "";

        uriString = twitterGetUrl + "?";
        uriString = addParamToURI(uriString, "id", id, true);

        return new URI(uriString);

    }





    public static String addParamToURI(String uriString, String name, String value, boolean first)
    {
        if(first == false)
        {
            uriString = uriString + "&";
        }
        uriString = uriString + name + "=" + value;

        return uriString;
    }




    public static Tweet validateTweetResponse (HttpResponse response, Integer expectedStatusCode){

        String jsonString;
        Tweet tweet = null;
        int status = response.getStatusLine().getStatusCode();

        if (status != expectedStatusCode) {
            throw new RuntimeException("Unexpected HTTP status:" + status);
        }

        if(response.getEntity() == null) {
            throw new RuntimeException("Empty response body");
        }

        try {
            jsonString = EntityUtils.toString(response.getEntity());
        }catch(IOException e){
            throw new RuntimeException("Failed to convert Tweet to String", e);
        }

        try {
            tweet = (Tweet) JsonParser.toObjectFromJson(jsonString, Tweet.class);
        }catch (IOException e) {
            throw new RuntimeException("Unable to convert JSON String to Object", e);
        }

        return tweet;

    }




}