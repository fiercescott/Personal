package ca.jrvs.apps.twitter.service;

import ca.jrvs.apps.twitter.dao.TwitterRestDao;
import ca.jrvs.apps.twitter.example.dto.Coordinates;
import ca.jrvs.apps.twitter.example.dto.Tweet;

public class TwitterServiceImp implements TwitterService {


    public void postTweet(String text, Double latitude, Double longitude) {

        Tweet newTweet = null;
        Coordinates newCoordinates = null;
        double[] coords = {latitude,longitude};

        newTweet.setText(text);
        newCoordinates.setCoordinates(coords);
        newTweet.setCoordinates(newCoordinates);
    }


    public void showTweet(String id, String[] fields) {

        Tweet tweet = null;
        tweet = TwitterRestDao.getTweetById(id);

    }


    public void deleteTweets(String[] ids) {

        for(int i = 0; i<ids.length; i++)
        {
            TwitterRestDao.deleteTweetById(ids[i]);
        }
    }
}