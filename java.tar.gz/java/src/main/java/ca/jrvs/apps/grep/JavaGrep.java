package ca.jrvs.apps.grep;

import java.io.File;
import java.io.IOException;
import java.util.List;

public interface JavaGrep {

    public void process() throws IOException;
    public List<File> listFiles(String path, List<File> listOfFiles) throws IOException;
    public List<String> readLines(List<File> listOfFiles) throws IOException;
    public boolean containsPattern(String line, String searchWord);
    public String getRootPath();
    public void setRootPath(String rootPath);
    public String getRegex();
    public void setRegex(String regex);
    public String getOutFile();
    public void setOutFile(String outFile);

}