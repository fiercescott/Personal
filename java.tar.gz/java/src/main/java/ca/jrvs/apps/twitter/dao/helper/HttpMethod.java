package ca.jrvs.apps.twitter.dao.helper;


import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.entity.StringEntity;


import java.net.URI;

public class HttpMethod implements HttpHelper {

    static String consumerKeyStr = "fH03Chc2YOcuP3OOuMcOfvrmc";
    static String consumerSecretStr = "3mEAK7pMpiB7dcE4cWLLVmxwPeOAr2HHiCXcDVfEE6ut3zFBIf";
    static String accessTokenStr = "1144303955297673218-9imbJs9lycc6UzRVusK0N0vshplOdu";
    static String accessTokenSecretStr = "HhNViIx6pE0WGkCJXnX8El8LHufpAjE3tehKzdWVd5Qdu";

    String TWITTER_ADDRESS = "https://twitter.com/ScottCo82906456";

    public static void main (String args[]){

        HttpGet httpget = new HttpGet(
                "http://www.google.com/search?hl=en&q=httpclient&btnG=Google+Search&aq=f&oq=");

    }



    @Override
    public HttpResponse httpPost(URI uri) {
        return null;
    }

    @Override
    public HttpResponse httpPost(URI uri, StringEntity stringEntity) {
        return null;
    }

    @Override
    public HttpResponse httpGet(URI uri) {
        return null;
    }
}