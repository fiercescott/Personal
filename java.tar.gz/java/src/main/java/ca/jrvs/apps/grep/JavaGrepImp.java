package ca.jrvs.apps.grep;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class JavaGrepImp implements  JavaGrep{

    private static String regexString = "";
    private static String directoryString = "";
    private static String outputString = "";

    public List<File> listFiles(String path, List<File> listOfFiles) throws IOException {
        File startPoint = new File(path);

        File[] files = startPoint.listFiles();

        for (File fileEntry : startPoint.listFiles()) {
            if (fileEntry.isDirectory()) {
                //System.out.println("Directory: " + fileEntry.getName());
                //path = path+"\\"+fileEntry.getName();
                //System.out.println(path);
                listOfFiles = listFiles((path + "\\" + fileEntry.getName()), listOfFiles);
            } else {
                //System.out.println("File: " + fileEntry.getName());
                //readFile(fileEntry);
                listOfFiles.add(fileEntry);
                //System.out.println("Added file: " + fileEntry.getName());
            }
        }

        //System.out.println(listOfFiles);
        return listOfFiles;
    }

    public List<String> readLines(List<File> listOfFiles) throws IOException {
        int i = 0;
        List<String> listOfStrings = new ArrayList<String>();

        for (i = 0; i < listOfFiles.size(); i++) {
            //System.out.println(listOfFiles.get(i));

            BufferedReader br = new BufferedReader(new FileReader(listOfFiles.get(i)));
            String st;
            while ((st = br.readLine()) != null) {
                //System.out.println(st);
                listOfStrings.add(st);
            }
        }

        return listOfStrings;
    }


    public boolean containsPattern(String line, String searchWord) {
        Pattern regexSearch = Pattern.compile(searchWord);
        Matcher regexMatch = regexSearch.matcher(line);
        if (regexMatch.find()) {
            System.out.println(line);
            return true;
        }
        return false;
    }


    public void process() throws IOException {
        int i = 0;
        List<File> listOfFiles = new ArrayList<File>();
        List<String> listOfStrings = new ArrayList<String>();
        PrintWriter outputFile = new PrintWriter("regexOutput.txt");

        String startingLocation = "C:\\Users\\Scott\\IdeaProjects\\grep_app\\src\\folder1";

        listOfFiles = listFiles(startingLocation, listOfFiles);
        listOfStrings = readLines(listOfFiles);


        for (i = 0; i < listOfFiles.size(); i++) {
            System.out.println(listOfFiles.get(i));
        }

        for (i = 0; i < listOfStrings.size(); i++) {
            //System.out.println(listOfStrings.get(i));
            if (containsPattern(listOfStrings.get(i), "(just)") == true) {
                System.out.println("^ Found");
                outputFile.println(listOfStrings.get(i));
            }
        }

        outputFile.close();
    }


    public String getRootPath()
    {
        return directoryString;
    }

    public void setRootPath(String rootPath)
    {
        directoryString = rootPath;
    }

    public String getRegex()
    {
        return regexString;
    }

    public void setRegex(String regex)
    {
        regexString = regex;
    }

    public String getOutFile()
    {
        return outputString;
    }

    public void setOutFile(String outFile)
    {
        outputString = outFile;
    }




    public static void main (String args[]) throws IOException
    {
        if (args.length != 3)
        {
            throw new IllegalArgumentException("USAGE: regex rootPath outputFile");
        }

        JavaGrepImp javaGrepImp = new JavaGrepImp();
        javaGrepImp.setRegex(args[0]);
        javaGrepImp.setRootPath(args[1]);
        javaGrepImp.setOutFile(args[2]);


        System.out.println("Regex: " + javaGrepImp.getRegex());
        System.out.println("Root Path: " + javaGrepImp.getRootPath());
        System.out.println("Output File: " + javaGrepImp.getOutFile());
        //String regexString = args[0];
        //String directoryString = args[1];
        //String outputString = args[2];

        try {
            javaGrepImp.process();
        } catch (Exception ex) {
            ex.printStackTrace();
        }



    }
}
