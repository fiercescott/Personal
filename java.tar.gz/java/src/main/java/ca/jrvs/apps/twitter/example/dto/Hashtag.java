package ca.jrvs.apps.twitter.example.dto;


public class Hashtag{

    int[] indices;
    String text;

    public int[] getIndices() {
        return indices;
    }

    public void setIndices(int[] indices) {
        this.indices = indices;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}