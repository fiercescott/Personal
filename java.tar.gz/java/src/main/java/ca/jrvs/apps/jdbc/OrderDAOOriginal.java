package ca.jrvs.apps.jdbc;

import ca.jrvs.apps.jdbc.util.DataAccessObject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class OrderDAOOriginal extends DataAccessObject<OrderOriginal> {

    private static final String GET_ONE = "SELECT customer_id, first_name, last_name, email, " +
            "phone, address, city, state, zipcode From customer Where customer_id=?";

    public OrderDAOOriginal(Connection connection) {
        super(connection);
    }

    @Override
    public OrderOriginal findById(long id) {
        OrderOriginal order = new OrderOriginal();
        try (PreparedStatement statement = this.connection.prepareStatement(GET_ONE);) {
            statement.setLong(1, id);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                order.setCustomerFirstName(rs.getString("customerFirstName"));
                order.setCustomerLastName(rs.getString("customerLastName"));
                order.setCustomerEmail(rs.getString("customerEmail"));
                order.setCustomerOrderId(rs.getLong("customerOrderId"));
                order.setOrderCreationDate(rs.getDate("orderCreationDate"));
                order.setOrderTotalDue(rs.getBigDecimal("orderTotalDue"));
                order.setOrderStatus(rs.getString("orderStatus"));
                order.setSalespersonFirstName(rs.getString("salespersonFirstName"));
                order.setSalespersonLastName(rs.getString("salespersonLastName"));
                order.setSalespersonEmail(rs.getString("salespersonEmail"));
                order.setOrderItemQuantity(rs.getInt("orderItemQuantity"));
                order.setProductCode(rs.getString("productCode"));
                order.setProductName(rs.getString("productName"));
                order.setProductSize(rs.getInt("productSize"));
                order.setProductVariety(rs.getString("productVariety"));
                order.setProductPrice(rs.getBigDecimal("productPrice"));

            }


        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }


        return order;
    }

    @Override
    public List<OrderOriginal> findAll() {
        return null;
    }

    @Override
    public OrderOriginal update(OrderOriginal dto) {
        return null;
    }

    @Override
    public OrderOriginal create(OrderOriginal dto) {
        return null;
    }

    @Override
    public void delete(long id) {

    }
}