package ca.jrvs.apps.jdbc.util;

public interface DataTransferObject {

    long getId();
}