package ca.jrvs.apps.twitter.example;


import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.core.JsonParser.Feature;
import com.fasterxml.jackson.databind.ObjectMapper;
import jdk.internal.org.objectweb.asm.TypeReference;

import java.io.File;
import java.io.IOException;
import java.lang.Class;

public class JsonParser {


    public static void main(String[] args) throws Exception {


        String tempString;
        Company com = new Company();

        com = createCompany();

        tempString = "cat";
        tempString = toJson(com, false, false);
        System.out.println("hi\n"+tempString);


        com = toObjectFromJson(tempString, Company.class);
/*
        com.setSymbol(null);
        if(com.getSymbol() == null)
        {
            System.out.println("hi");
        }
*/


    }

    public static String toJson(Object object, Boolean prettyJson, boolean includeNullValues) throws IOException {

        String jsonString = "";
        String jsonString2 = "";

        ObjectMapper mapper = new ObjectMapper();

        try{



            if (includeNullValues == true)
            {
                System.out.println("Hello");
                mapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
            }


            mapper.writeValue(new File("Company.json"), object);

            if(prettyJson == true)
            {
                jsonString2 = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(object);
                System.out.println(jsonString2);
            }
            else
            {
                jsonString = mapper.writeValueAsString(object);
                System.out.println(jsonString);
            }

        } catch (IOException e){
            e.printStackTrace();
        }



        return jsonString;
    }

/*
    public static <T> T toObjectFromJson(String json ,Class clazz) throws IOException
    {
        ObjectMapper mapper = new ObjectMapper();

        String fPath = "/home/centos/dev/jrvs/bootcamp/host_agent/java//src/main/java/ca/jrvs/apps/twitter/example/test.json";

//mapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
       // mapper.configure(Feature.AUTO_CLOSE_SOURCE, true);
        try {
            //clazz = mapper.readValue(new File(fPath), Class.class);
            System.out.println(json);
            return (T) = mapper.readValue(json, clazz);




        }catch (IOException e){
            e.printStackTrace();
        }

        return (T) clazz;
    }
*/

    public static <T> T toObjectFromJson(String json, Class clazz) throws IOException {
        ObjectMapper m = new ObjectMapper();
        m.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return (T) m.readValue(json, clazz);
    }



    private static Company createCompany() {
        Company com = new Company();
        com.setSymbol("Cat");
        com.setCompanyName("Com Name");
        com.setExchange("Ex");
        com.setDescription("Its a company");
        com.setCEO("Tom");
        com.setSector("");
        com.setFinancials(null);
        com.setDividends(null);

        return com;
    }


    /*
    public static String toJson(Object object, boolean prettyJson, boolean includeNullValues) throws JsonProcessingException
    {
        String jsonString = "";

        jsonString = JSON.stringify(object);

        return jsonString;
    }


    public static <T> T toObjectFromJson(String json, Class clazz) throws IOException
    {

    }

     */


}